document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.parallax');
    var instances = M.Parallax.init(elems);
    // elems = document.querySelectorAll('.collapsible');
    // instances = M.Collapsible.init(elems);
    // elems = document.querySelectorAll('.tabs')
    // var instance = M.Tabs.init(elems, {swipeable:true});
});